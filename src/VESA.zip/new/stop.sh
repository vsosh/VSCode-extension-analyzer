killall python app.py
killall init.sh
killall strace.py
killall main.py
killall get_sys_info.py
